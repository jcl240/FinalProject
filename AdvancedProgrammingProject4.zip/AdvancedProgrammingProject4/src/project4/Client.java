package project4;

import java.net.Socket;

public class Client 
{
	public static void main(String[] args) throws Exception
	{
		Socket newSocket=new Socket("localhost", 9999);
		System.out.println("Success!");
	}
}
